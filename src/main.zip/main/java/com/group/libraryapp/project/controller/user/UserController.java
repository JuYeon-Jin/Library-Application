package com.group.libraryapp.project.controller.user;

import com.group.libraryapp.project.dto.user.UserDTO;
import com.group.libraryapp.project.service.user.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collection;
import java.util.Iterator;

@Controller
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/")
    public String homepage(Model model) {
        return "view/user/home";
    }

    // 회원 가입
    @PostMapping("/join")
    public String join(UserDTO dto) {
        userService.joinProcess(dto);
        return "redirect:/";
    }

    // 로그인 → 페이지 분기 ADMIN / USER
    @GetMapping("/authBranch")
    public String login() {
        System.out.println("UserController.login");

        String id = SecurityContextHolder.getContext().getAuthentication().getName();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        Iterator<? extends GrantedAuthority> iter = authorities.iterator();
        GrantedAuthority auth = iter.next();
        String role = auth.getAuthority();

        if (role.equals("ROLE_ADMIN")) {
            return "view/admin/bookForm";
        }
        return "redirect:/user/mybook";
    }

    // 내 책 목록
    @GetMapping("/user/mybook")
    public String myBookList(ModelAndView mav) {
        mav.setViewName("/view/user/myBook");
        // mav.addObject("posts",postService.allPosts());

        return "view/user/myBook";
    }
/*
    // CREATE   * 회원 가입
    @PostMapping("/join")
    public void saveUser(@RequestBody UserRequest request) {
        userService.saveUser(request);
    }

    // READ   * 회원 전체 목록 조회
    @GetMapping("/admin/userlist")
    public List<UserResponse> getUsers(ModelAndView mav) {
        return userService.getUsers();
        //        mav.setViewName("/post/my-posts");
        //        mav.addObject("posts",postService.allPosts());
    }
*/
    /*
    // READ   * 회원 전체 목록 조회
    @GetMapping("/user")
    public List<UserResponse> getUsers() {
        return userService.getUsers();
    }

    // UPDATE   * 비밀번호 수정
    @PutMapping("/user")
    public void updateUser(@RequestBody UserUpdateRequest request) {
       userService.updateUser(request);
    }

    // DELETE   * 회원 탈퇴
    @DeleteMapping("/user")
    public void deleteUser(@RequestParam String name) {
        userService.deleteUser(name);
    }
    */

}
