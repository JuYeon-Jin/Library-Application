package com.group.libraryapp.project.controller.user;

import org.springframework.web.bind.annotation.GetMapping;

public class AdminController {

    // 책 등록 PAGE
    @GetMapping("/admin/bookform")
    public String bookForm() {
        return "view/admin/bookForm";
    }

}
