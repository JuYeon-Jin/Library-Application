package com.group.libraryapp.project.service.book;

import org.springframework.stereotype.Service;

@Service
public class BookLoanService {
}
