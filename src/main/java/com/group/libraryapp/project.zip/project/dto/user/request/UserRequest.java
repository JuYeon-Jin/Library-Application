package com.group.libraryapp.project.dto.user.request;

import lombok.Getter;

@Getter
public class UserRequest {

    private String id;
    private String pw;

}
