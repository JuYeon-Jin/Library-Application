package com.group.libraryapp.project.domain.bookLoanHistory;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LoanhistoryRepository extends JpaRepository<Loanhistory, Integer> {
    List<Loanhistory> findByUserIdAndReturnBook(String userId, boolean returnBook);
}
